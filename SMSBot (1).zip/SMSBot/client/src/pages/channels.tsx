import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

interface Channel {
  id: string;
  name: string;
  username: string;
  chatId?: string;
  isActive: boolean;
  members: number;
  createdAt: string;
}

export default function Channels() {
  const [newChannelName, setNewChannelName] = useState("");
  const [newChannelUsername, setNewChannelUsername] = useState("");
  
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: channels = [], isLoading } = useQuery<Channel[]>({
    queryKey: ['/api/channels'],
  });

  const createChannelMutation = useMutation({
    mutationFn: (data: { name: string; username: string }) => 
      apiRequest('POST', '/api/channels', data),
    onSuccess: () => {
      toast({
        title: "تم الحفظ",
        description: "تم إضافة القناة بنجاح",
      });
      setNewChannelName("");
      setNewChannelUsername("");
      queryClient.invalidateQueries({ queryKey: ['/api/channels'] });
    },
    onError: () => {
      toast({
        title: "خطأ",
        description: "فشل في إضافة القناة",
        variant: "destructive",
      });
    },
  });

  const deleteChannelMutation = useMutation({
    mutationFn: (id: string) => apiRequest('DELETE', `/api/channels/${id}`, {}),
    onSuccess: () => {
      toast({
        title: "تم الحذف",
        description: "تم حذف القناة بنجاح",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/channels'] });
    },
    onError: () => {
      toast({
        title: "خطأ",
        description: "فشل في حذف القناة",
        variant: "destructive",
      });
    },
  });

  const handleAddChannel = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newChannelName.trim() || !newChannelUsername.trim()) return;
    
    createChannelMutation.mutate({
      name: newChannelName,
      username: newChannelUsername
    });
  };

  const handleDeleteChannel = (id: string) => {
    if (confirm('هل أنت متأكد من حذف هذه القناة؟')) {
      deleteChannelMutation.mutate(id);
    }
  };

  if (isLoading) {
    return (
      <div className="flex-1 p-6">
        <div className="animate-pulse">
          <div className="h-8 bg-gray-200 rounded w-48 mb-6"></div>
          <div className="h-64 bg-gray-200 rounded"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 p-6">
      {/* Header */}
      <header className="bg-white shadow-sm border-b px-6 py-4 -mx-6 -mt-6 mb-6">
        <h2 className="text-2xl font-semibold text-gray-800" data-testid="page-title">
          قنوات الاشتراك الإجباري
        </h2>
      </header>

      <Card>
        <CardHeader>
          <div className="flex justify-between items-center">
            <CardTitle>قائمة القنوات</CardTitle>
          </div>
        </CardHeader>
        
        <CardContent>
          {/* Channels List */}
          <div className="space-y-4 mb-8">
            {channels.length === 0 ? (
              <p className="text-gray-500 text-center py-8" data-testid="text-no-channels">
                لا توجد قنوات مضافة
              </p>
            ) : (
              channels.map((channel) => (
                <div 
                  key={channel.id} 
                  className="border rounded-lg p-4 flex items-center justify-between"
                  data-testid={`channel-${channel.id}`}
                >
                  <div className="flex items-center space-x-3 space-x-reverse">
                    <div className="h-12 w-12 bg-telegram-blue rounded-lg flex items-center justify-center text-white">
                      <i className="fas fa-hashtag"></i>
                    </div>
                    <div>
                      <h4 className="font-medium" data-testid={`channel-name-${channel.id}`}>
                        {channel.name}
                      </h4>
                      <p className="text-sm text-gray-500" data-testid={`channel-username-${channel.id}`}>
                        {channel.username}
                      </p>
                      <p className="text-xs text-gray-400">
                        الأعضاء:{' '}
                        <span data-testid={`channel-members-${channel.id}`}>
                          {channel.members || 0}
                        </span>
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2 space-x-reverse">
                    <div className="flex items-center">
                      <span className="text-xs text-gray-500 ml-2">حالة:</span>
                      <Badge 
                        variant={channel.isActive ? "default" : "secondary"}
                        data-testid={`channel-status-${channel.id}`}
                      >
                        {channel.isActive ? 'نشط' : 'غير نشط'}
                      </Badge>
                    </div>
                    <Button 
                      variant="ghost" 
                      size="sm"
                      className="text-error hover:text-red-600 p-2"
                      onClick={() => handleDeleteChannel(channel.id)}
                      data-testid={`button-delete-channel-${channel.id}`}
                    >
                      <i className="fas fa-trash"></i>
                    </Button>
                  </div>
                </div>
              ))
            )}
          </div>

          {/* Add Channel Form */}
          <div className="p-4 bg-gray-50 rounded-lg">
            <h4 className="font-medium mb-4">إضافة قناة جديدة</h4>
            <form onSubmit={handleAddChannel} className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Input 
                placeholder="اسم القناة"
                value={newChannelName}
                onChange={(e) => setNewChannelName(e.target.value)}
                data-testid="input-channel-name"
              />
              <Input 
                placeholder="@username"
                value={newChannelUsername}
                onChange={(e) => setNewChannelUsername(e.target.value)}
                data-testid="input-channel-username"
              />
              <Button 
                type="submit"
                className="bg-success text-white hover:bg-green-600"
                disabled={createChannelMutation.isPending || !newChannelName.trim() || !newChannelUsername.trim()}
                data-testid="button-add-channel"
              >
                {createChannelMutation.isPending ? 'جاري الإضافة...' : 'إضافة'}
              </Button>
            </form>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
