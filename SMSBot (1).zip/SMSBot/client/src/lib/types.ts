export interface User {
  id: string;
  username?: string;
  firstName?: string;
  lastName?: string;
  balance?: string;
  numbersUsed?: number;
  isBlocked?: boolean;
  createdAt?: string;
  updatedAt?: string;
}

export interface Transaction {
  id: string;
  userId?: string;
  type: 'credit' | 'debit';
  amount?: string;
  description?: string;
  service?: string;
  country?: string;
  phoneNumber?: string;
  verificationCode?: string;
  status: 'pending' | 'completed' | 'failed';
  createdAt?: string;
}

export interface SubscriptionChannel {
  id: string;
  name: string;
  username: string;
  chatId?: string;
  isActive: boolean;
  members?: number;
  createdAt?: string;
}

export interface BotSettings {
  id: string;
  maintenanceMode: boolean;
  maintenanceMessage?: string;
  numberPrice?: string;
  minimumBalance?: string;
  dailyLimit?: number;
  referralCommission?: number;
  apiUrl?: string;
  apiToken?: string;
  apiTimeout?: number;
  apiRetries?: number;
  welcomeMessage?: string;
  supportedServices?: string[];
  supportedCountries?: Array<{
    code: string;
    name: string;
    flag: string;
  }>;
  updatedAt?: string;
}

export interface Message {
  id: string;
  type: 'broadcast' | 'direct';
  content: string;
  targetUserId?: string;
  recipientCount?: number;
  openRate?: number;
  status: 'pending' | 'sent' | 'failed';
  createdAt?: string;
}

export interface Statistics {
  id: string;
  date?: string;
  totalUsers?: number;
  numbersReceived?: number;
  codesSent?: number;
  totalRevenue?: string;
  successRate?: string;
  avgResponseTime?: string;
  dailyRevenue?: string;
}
