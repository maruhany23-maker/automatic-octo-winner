# Telegram Bot Admin Dashboard

## Overview

This is a full-stack web application for managing a Telegram bot that provides virtual phone numbers for SMS verification services. The system consists of a React-based admin dashboard for monitoring and configuration, and a Node.js backend with Express server that handles both web API requests and Telegram bot operations. The application manages users, transactions, subscription channels, messaging, and bot settings through a comprehensive admin interface.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React with TypeScript using Vite as the build tool
- **UI Components**: Radix UI primitives with shadcn/ui component library for consistent design
- **Styling**: Tailwind CSS with CSS variables for theming and RTL (right-to-left) support for Arabic interface
- **State Management**: TanStack Query (React Query) for server state management and data fetching
- **Routing**: Wouter for lightweight client-side routing
- **Form Handling**: React Hook Form with Zod for validation

### Backend Architecture
- **Server Framework**: Express.js with TypeScript
- **Bot Framework**: node-telegram-bot-api for Telegram bot integration
- **Database ORM**: Drizzle ORM for type-safe database operations
- **API Design**: RESTful API with structured error handling and request/response logging
- **Development**: Hot module replacement with Vite middleware in development mode

### Data Storage Solutions
- **Primary Database**: PostgreSQL with Neon serverless hosting
- **Schema Management**: Drizzle Kit for migrations and schema management
- **Connection Pooling**: Neon serverless connection pooling with WebSocket support
- **Data Models**: Users, transactions, subscription channels, bot settings, messages, and statistics

### Authentication and Authorization
- **Bot Authentication**: Telegram Bot Token-based authentication
- **Session Management**: No explicit user authentication system shown - appears to be internal admin tool
- **Data Access**: Direct database access through storage abstraction layer

### External Dependencies
- **Database**: Neon PostgreSQL serverless database
- **Telegram**: Telegram Bot API for bot operations
- **UI Libraries**: Extensive use of Radix UI primitives for accessible components
- **Development Tools**: Replit-specific plugins for development environment integration
- **Styling**: Font Awesome for icons, Google Fonts for typography

The architecture follows a clear separation between the admin interface and bot operations, with a shared database layer and API that serves both the web dashboard and handles bot webhook/polling events. The system is designed for managing a commercial SMS verification service with Arabic language support.