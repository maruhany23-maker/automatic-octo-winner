import { Card, CardContent } from "@/components/ui/card";

interface StatCardProps {
  title: string;
  value: string;
  icon: string;
  color: string;
}

export default function StatCard({ title, value, icon, color }: StatCardProps) {
  return (
    <Card>
      <CardContent className="p-6">
        <div className="flex items-center">
          <div className={`p-3 bg-opacity-20 rounded-lg ${color}`}>
            <i className={`${icon} text-xl`}></i>
          </div>
          <div className="mr-4">
            <p className="text-sm text-gray-600" data-testid={`stat-title-${title.replace(/\s+/g, '-')}`}>
              {title}
            </p>
            <p className="text-2xl font-bold" data-testid={`stat-value-${title.replace(/\s+/g, '-')}`}>
              {value}
            </p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
