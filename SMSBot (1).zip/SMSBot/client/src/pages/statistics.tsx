import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export default function Statistics() {
  const { data: stats, isLoading } = useQuery({
    queryKey: ['/api/dashboard/stats'],
  });

  if (isLoading) {
    return (
      <div className="flex-1 p-6">
        <div className="animate-pulse">
          <div className="h-8 bg-gray-200 rounded w-48 mb-6"></div>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="h-64 bg-gray-200 rounded"></div>
            <div className="h-64 bg-gray-200 rounded"></div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 p-6">
      {/* Header */}
      <header className="bg-white shadow-sm border-b px-6 py-4 -mx-6 -mt-6 mb-6">
        <h2 className="text-2xl font-semibold text-gray-800" data-testid="page-title">
          الإحصائيات
        </h2>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Chart Cards */}
        <Card>
          <CardHeader>
            <CardTitle>الأرقام المستخدمة (آخر 7 أيام)</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-64 bg-gray-50 rounded flex items-center justify-center" data-testid="chart-numbers-used">
              <p className="text-gray-500">مخطط الاستخدام اليومي</p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>توزيع الخدمات</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-64 bg-gray-50 rounded flex items-center justify-center" data-testid="chart-services">
              <p className="text-gray-500">مخطط دائري للخدمات</p>
            </div>
          </CardContent>
        </Card>

        {/* Detailed Stats */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle>إحصائيات تفصيلية</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="text-center">
                <div className="text-3xl font-bold text-telegram-blue" data-testid="stat-success-rate">
                  {stats?.successRate || '87'}%
                </div>
                <p className="text-sm text-gray-600">معدل النجاح</p>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-success" data-testid="stat-response-time">
                  {stats?.avgResponseTime || '2.3'}s
                </div>
                <p className="text-sm text-gray-600">متوسط وقت الاستجابة</p>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-warning" data-testid="stat-daily-revenue">
                  ${stats?.dailyRevenue || '234'}
                </div>
                <p className="text-sm text-gray-600">إيرادات اليوم</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
