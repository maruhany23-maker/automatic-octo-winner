import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import AddBalanceModal from "@/components/modals/add-balance-modal";
import { User } from "@/lib/types";

export default function Users() {
  const [searchQuery, setSearchQuery] = useState("");
  const [showAddBalance, setShowAddBalance] = useState(false);
  const [selectedUserId, setSelectedUserId] = useState<string>("");

  const { data: users = [], isLoading } = useQuery<User[]>({
    queryKey: ['/api/users', searchQuery],
    queryFn: async () => {
      const params = searchQuery ? `?search=${encodeURIComponent(searchQuery)}` : '';
      const response = await fetch(`/api/users${params}`);
      if (!response.ok) throw new Error('Failed to fetch users');
      return response.json();
    },
  });

  const handleAddBalance = (userId: string) => {
    setSelectedUserId(userId);
    setShowAddBalance(true);
  };

  if (isLoading) {
    return (
      <div className="flex-1 p-6">
        <div className="animate-pulse">
          <div className="h-8 bg-gray-200 rounded w-48 mb-6"></div>
          <div className="h-64 bg-gray-200 rounded"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 p-6">
      {/* Header */}
      <header className="bg-white shadow-sm border-b px-6 py-4 -mx-6 -mt-6 mb-6">
        <h2 className="text-2xl font-semibold text-gray-800" data-testid="page-title">
          إدارة المستخدمين
        </h2>
      </header>

      <Card>
        <CardHeader>
          <div className="flex justify-between items-center">
            <CardTitle>قائمة المستخدمين</CardTitle>
            <div className="flex space-x-3 space-x-reverse">
              <Input 
                placeholder="البحث بالآيدي أو الاسم..." 
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-64"
                data-testid="input-search-users"
              />
              <Button 
                className="bg-success text-white hover:bg-green-600"
                onClick={() => handleAddBalance("")}
                data-testid="button-add-balance-general"
              >
                <i className="fas fa-plus ml-2"></i>
                إضافة رصيد
              </Button>
            </div>
          </div>
        </CardHeader>
        
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="text-right">المستخدم</TableHead>
                  <TableHead className="text-right">الرصيد</TableHead>
                  <TableHead className="text-right">الأرقام المستخدمة</TableHead>
                  <TableHead className="text-right">تاريخ التسجيل</TableHead>
                  <TableHead className="text-right">الإجراءات</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {users.map((user) => (
                  <TableRow key={user.id} data-testid={`user-row-${user.id}`}>
                    <TableCell>
                      <div className="flex items-center">
                        <Avatar className="h-8 w-8 bg-telegram-blue">
                          <AvatarFallback className="text-white text-sm">
                            {user.firstName?.charAt(0) || user.username?.charAt(0) || 'U'}
                          </AvatarFallback>
                        </Avatar>
                        <div className="mr-3">
                          <p className="text-sm font-medium" data-testid={`user-name-${user.id}`}>
                            {user.firstName || user.username || 'مستخدم'}
                          </p>
                          <p className="text-xs text-gray-500" data-testid={`user-username-${user.id}`}>
                            @{user.username || user.id}
                          </p>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <span className="text-sm font-medium" data-testid={`user-balance-${user.id}`}>
                        ${user.balance || '0.00'}
                      </span>
                    </TableCell>
                    <TableCell>
                      <span className="text-sm" data-testid={`user-numbers-${user.id}`}>
                        {user.numbersUsed || 0}
                      </span>
                    </TableCell>
                    <TableCell>
                      <span className="text-sm text-gray-500" data-testid={`user-date-${user.id}`}>
                        {new Date(user.createdAt || '').toLocaleDateString('ar-EG')}
                      </span>
                    </TableCell>
                    <TableCell>
                      <div className="flex space-x-2 space-x-reverse">
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          className="text-telegram-blue hover:text-telegram-dark"
                          onClick={() => handleAddBalance(user.id)}
                          data-testid={`button-edit-balance-${user.id}`}
                        >
                          <i className="fas fa-edit"></i>
                        </Button>
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          className="text-success hover:text-green-600"
                          data-testid={`button-message-${user.id}`}
                        >
                          <i className="fas fa-paper-plane"></i>
                        </Button>
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          className="text-error hover:text-red-600"
                          data-testid={`button-block-${user.id}`}
                        >
                          <i className="fas fa-ban"></i>
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      <AddBalanceModal 
        open={showAddBalance} 
        onOpenChange={setShowAddBalance}
        userId={selectedUserId}
      />
    </div>
  );
}
