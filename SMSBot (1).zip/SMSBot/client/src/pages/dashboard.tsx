import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import StatCard from "@/components/stat-card";
import BotInterface from "@/components/bot-interface";
import AddBalanceModal from "@/components/modals/add-balance-modal";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

interface DashboardStats {
  totalUsers: number;
  numbersReceived: number;
  codesSent: number;
  totalRevenue: string;
  successRate: string;
  avgResponseTime: string;
  dailyRevenue: string;
}

export default function Dashboard() {
  const [showAddBalance, setShowAddBalance] = useState(false);
  const [showBotInterface, setShowBotInterface] = useState(false);
  const { toast } = useToast();

  const { data: stats, isLoading } = useQuery<DashboardStats>({
    queryKey: ['/api/dashboard/stats'],
  });

  const handleBroadcast = async () => {
    try {
      const message = prompt("اكتب الرسالة الجماعية:");
      if (!message) return;

      await apiRequest('POST', '/api/messages/broadcast', { content: message });
      toast({
        title: "تم الإرسال",
        description: "تم إرسال الرسالة الجماعية بنجاح",
      });
    } catch (error) {
      toast({
        title: "خطأ",
        description: "فشل في إرسال الرسالة",
        variant: "destructive",
      });
    }
  };

  if (isLoading) {
    return (
      <div className="flex-1 p-6">
        <div className="animate-pulse">
          <div className="h-8 bg-gray-200 rounded w-48 mb-6"></div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="h-24 bg-gray-200 rounded"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 p-6">
      {/* Header */}
      <header className="bg-white shadow-sm border-b px-6 py-4 -mx-6 -mt-6 mb-6">
        <div className="flex items-center justify-between">
          <h2 className="text-2xl font-semibold text-gray-800" data-testid="page-title">
            لوحة التحكم
          </h2>
          <div className="flex items-center space-x-4 space-x-reverse">
            <div className="flex items-center space-x-2 space-x-reverse">
              <span className="text-sm text-gray-600">حالة البوت:</span>
              <span className="px-2 py-1 bg-success text-white text-xs rounded-full" data-testid="bot-status">
                نشط
              </span>
            </div>
            <Button variant="ghost" size="sm">
              <i className="fas fa-tools"></i>
            </Button>
          </div>
        </div>
      </header>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <StatCard
          title="إجمالي المستخدمين"
          value={stats?.totalUsers?.toString() || "0"}
          icon="fas fa-users"
          color="bg-telegram-light text-telegram-blue"
        />
        <StatCard
          title="الأرقام المستلمة"
          value={stats?.numbersReceived?.toString() || "0"}
          icon="fas fa-phone"
          color="bg-success text-success"
        />
        <StatCard
          title="الأكواد المرسلة"
          value={stats?.codesSent?.toString() || "0"}
          icon="fas fa-sms"
          color="bg-warning text-warning"
        />
        <StatCard
          title="إجمالي الأرباح"
          value={`$${stats?.totalRevenue || "0"}`}
          icon="fas fa-dollar-sign"
          color="bg-telegram-dark text-telegram-dark"
        />
      </div>

      {/* Quick Actions */}
      <Card className="mb-8">
        <CardHeader>
          <CardTitle>الإجراءات السريعة</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Button 
              variant="outline" 
              className="flex items-center p-4 h-auto justify-start"
              onClick={() => setShowAddBalance(true)}
              data-testid="button-add-balance"
            >
              <i className="fas fa-plus-circle text-success text-xl ml-3"></i>
              <span>إضافة رصيد</span>
            </Button>
            <Button 
              variant="outline" 
              className="flex items-center p-4 h-auto justify-start"
              onClick={handleBroadcast}
              data-testid="button-broadcast"
            >
              <i className="fas fa-bullhorn text-telegram-blue text-xl ml-3"></i>
              <span>رسالة جماعية</span>
            </Button>
            <Button 
              variant="outline" 
              className="flex items-center p-4 h-auto justify-start"
              onClick={() => setShowBotInterface(true)}
              data-testid="button-bot-interface"
            >
              <i className="fas fa-comments text-gray-600 text-xl ml-3"></i>
              <span>واجهة البوت</span>
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Modals */}
      <AddBalanceModal 
        open={showAddBalance} 
        onOpenChange={setShowAddBalance}
      />
      
      <BotInterface 
        open={showBotInterface} 
        onOpenChange={setShowBotInterface}
      />
    </div>
  );
}
