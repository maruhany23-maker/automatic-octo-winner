import { sql } from "drizzle-orm";
import { pgTable, varchar, text, decimal, integer, timestamp, boolean, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey(),
  username: varchar("username"),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  balance: decimal("balance", { precision: 10, scale: 2 }).default("0.00"),
  numbersUsed: integer("numbers_used").default(0),
  isBlocked: boolean("is_blocked").default(false),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const transactions = pgTable("transactions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id),
  type: varchar("type"), // 'credit', 'debit'
  amount: decimal("amount", { precision: 10, scale: 2 }),
  description: text("description"),
  service: varchar("service"),
  country: varchar("country"),
  phoneNumber: varchar("phone_number"),
  verificationCode: varchar("verification_code"),
  status: varchar("status").default("pending"), // 'pending', 'completed', 'failed'
  createdAt: timestamp("created_at").defaultNow(),
});

export const subscriptionChannels = pgTable("subscription_channels", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: varchar("name").notNull(),
  username: varchar("username").notNull(),
  chatId: varchar("chat_id"),
  isActive: boolean("is_active").default(true),
  members: integer("members").default(0),
  createdAt: timestamp("created_at").defaultNow(),
});

export const botSettings = pgTable("bot_settings", {
  id: varchar("id").primaryKey().default("main"),
  maintenanceMode: boolean("maintenance_mode").default(false),
  maintenanceMessage: text("maintenance_message").default("البوت تحت الصيانة، حاول لاحقاً"),
  numberPrice: decimal("number_price", { precision: 10, scale: 2 }).default("0.50"),
  minimumBalance: decimal("minimum_balance", { precision: 10, scale: 2 }).default("1.00"),
  dailyLimit: integer("daily_limit").default(10),
  referralCommission: integer("referral_commission").default(10),
  apiUrl: varchar("api_url"),
  apiToken: varchar("api_token"),
  apiTimeout: integer("api_timeout").default(30),
  apiRetries: integer("api_retries").default(3),
  welcomeMessage: text("welcome_message").default("مرحباً بك في بوت الأرقام! 🤖\nاختر الخدمة المطلوبة:"),
  supportedServices: jsonb("supported_services").default(["whatsapp", "telegram", "facebook", "instagram", "twitter"]),
  supportedCountries: jsonb("supported_countries").default([
    {"code": "EG", "name": "مصر", "flag": "🇪🇬"},
    {"code": "SA", "name": "السعودية", "flag": "🇸🇦"},
    {"code": "AE", "name": "الإمارات", "flag": "🇦🇪"},
    {"code": "US", "name": "أمريكا", "flag": "🇺🇸"}
  ]),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const messages = pgTable("messages", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  type: varchar("type"), // 'broadcast', 'direct'
  content: text("content").notNull(),
  targetUserId: varchar("target_user_id"),
  recipientCount: integer("recipient_count").default(0),
  openRate: integer("open_rate").default(0),
  status: varchar("status").default("pending"), // 'pending', 'sent', 'failed'
  createdAt: timestamp("created_at").defaultNow(),
});

export const statistics = pgTable("statistics", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  date: timestamp("date").defaultNow(),
  totalUsers: integer("total_users").default(0),
  numbersReceived: integer("numbers_received").default(0),
  codesSent: integer("codes_sent").default(0),
  totalRevenue: decimal("total_revenue", { precision: 10, scale: 2 }).default("0.00"),
  successRate: decimal("success_rate", { precision: 5, scale: 2 }).default("0.00"),
  avgResponseTime: decimal("avg_response_time", { precision: 10, scale: 2 }).default("0.00"),
  dailyRevenue: decimal("daily_revenue", { precision: 10, scale: 2 }).default("0.00"),
});

// Insert schemas
export const insertUserSchema = createInsertSchema(users);
export const insertTransactionSchema = createInsertSchema(transactions);
export const insertChannelSchema = createInsertSchema(subscriptionChannels);
export const insertSettingsSchema = createInsertSchema(botSettings);
export const insertMessageSchema = createInsertSchema(messages);
export const insertStatisticsSchema = createInsertSchema(statistics);

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type Transaction = typeof transactions.$inferSelect;
export type InsertTransaction = z.infer<typeof insertTransactionSchema>;
export type SubscriptionChannel = typeof subscriptionChannels.$inferSelect;
export type InsertChannel = z.infer<typeof insertChannelSchema>;
export type BotSettings = typeof botSettings.$inferSelect;
export type InsertSettings = z.infer<typeof insertSettingsSchema>;
export type Message = typeof messages.$inferSelect;
export type InsertMessage = z.infer<typeof insertMessageSchema>;
export type Statistics = typeof statistics.$inferSelect;
export type InsertStatistics = z.infer<typeof insertStatisticsSchema>;
