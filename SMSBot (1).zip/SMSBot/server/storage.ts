import { 
  users, transactions, subscriptionChannels, botSettings, messages, statistics,
  type User, type InsertUser, type Transaction, type InsertTransaction,
  type SubscriptionChannel, type InsertChannel, type BotSettings, type InsertSettings,
  type Message, type InsertMessage, type Statistics, type InsertStatistics
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, sql, and, gte, lte } from "drizzle-orm";

export interface IStorage {
  // User operations
  getUser(id: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserBalance(id: string, amount: string): Promise<User | undefined>;
  getAllUsers(): Promise<User[]>;
  searchUsers(query: string): Promise<User[]>;
  
  // Transaction operations
  createTransaction(transaction: InsertTransaction): Promise<Transaction>;
  getUserTransactions(userId: string): Promise<Transaction[]>;
  getAllTransactions(): Promise<Transaction[]>;
  updateTransactionStatus(id: string, status: string, code?: string): Promise<Transaction | undefined>;
  
  // Channel operations
  getSubscriptionChannels(): Promise<SubscriptionChannel[]>;
  createChannel(channel: InsertChannel): Promise<SubscriptionChannel>;
  deleteChannel(id: string): Promise<void>;
  updateChannelMembers(id: string, members: number): Promise<void>;
  
  // Settings operations
  getBotSettings(): Promise<BotSettings | undefined>;
  updateBotSettings(settings: Partial<InsertSettings>): Promise<BotSettings>;
  
  // Message operations
  createMessage(message: InsertMessage): Promise<Message>;
  getAllMessages(): Promise<Message[]>;
  updateMessageStatus(id: string, status: string, recipientCount?: number, openRate?: number): Promise<void>;
  
  // Statistics operations
  getLatestStatistics(): Promise<Statistics | undefined>;
  updateStatistics(stats: InsertStatistics): Promise<Statistics>;
  getStatisticsByDateRange(startDate: Date, endDate: Date): Promise<Statistics[]>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values({
      ...insertUser,
      createdAt: new Date(),
      updatedAt: new Date(),
    }).returning();
    return user;
  }

  async updateUserBalance(id: string, amount: string): Promise<User | undefined> {
    const [user] = await db
      .update(users)
      .set({ 
        balance: sql`${users.balance} + ${amount}`,
        updatedAt: new Date()
      })
      .where(eq(users.id, id))
      .returning();
    return user;
  }

  async getAllUsers(): Promise<User[]> {
    return await db.select().from(users).orderBy(desc(users.createdAt));
  }

  async searchUsers(query: string): Promise<User[]> {
    return await db.select().from(users)
      .where(
        sql`${users.username} ILIKE ${`%${query}%`} OR 
            ${users.firstName} ILIKE ${`%${query}%`} OR 
            ${users.lastName} ILIKE ${`%${query}%`} OR 
            ${users.id} ILIKE ${`%${query}%`}`
      );
  }

  async createTransaction(insertTransaction: InsertTransaction): Promise<Transaction> {
    const [transaction] = await db.insert(transactions).values({
      ...insertTransaction,
      createdAt: new Date(),
    }).returning();
    return transaction;
  }

  async getUserTransactions(userId: string): Promise<Transaction[]> {
    return await db.select().from(transactions)
      .where(eq(transactions.userId, userId))
      .orderBy(desc(transactions.createdAt));
  }

  async getAllTransactions(): Promise<Transaction[]> {
    return await db.select().from(transactions)
      .orderBy(desc(transactions.createdAt));
  }

  async updateTransactionStatus(id: string, status: string, code?: string): Promise<Transaction | undefined> {
    const updateData: any = { status };
    if (code) updateData.verificationCode = code;
    
    const [transaction] = await db
      .update(transactions)
      .set(updateData)
      .where(eq(transactions.id, id))
      .returning();
    return transaction;
  }

  async getSubscriptionChannels(): Promise<SubscriptionChannel[]> {
    return await db.select().from(subscriptionChannels)
      .where(eq(subscriptionChannels.isActive, true));
  }

  async createChannel(insertChannel: InsertChannel): Promise<SubscriptionChannel> {
    const [channel] = await db.insert(subscriptionChannels).values({
      ...insertChannel,
      createdAt: new Date(),
    }).returning();
    return channel;
  }

  async deleteChannel(id: string): Promise<void> {
    await db.update(subscriptionChannels)
      .set({ isActive: false })
      .where(eq(subscriptionChannels.id, id));
  }

  async updateChannelMembers(id: string, members: number): Promise<void> {
    await db.update(subscriptionChannels)
      .set({ members })
      .where(eq(subscriptionChannels.id, id));
  }

  async getBotSettings(): Promise<BotSettings | undefined> {
    const [settings] = await db.select().from(botSettings)
      .where(eq(botSettings.id, "main"));
    return settings;
  }

  async updateBotSettings(updateSettings: Partial<InsertSettings>): Promise<BotSettings> {
    const [settings] = await db.insert(botSettings).values({
      id: "main",
      ...updateSettings,
      updatedAt: new Date(),
    }).onConflictDoUpdate({
      target: botSettings.id,
      set: {
        ...updateSettings,
        updatedAt: new Date(),
      },
    }).returning();
    return settings;
  }

  async createMessage(insertMessage: InsertMessage): Promise<Message> {
    const [message] = await db.insert(messages).values({
      ...insertMessage,
      createdAt: new Date(),
    }).returning();
    return message;
  }

  async getAllMessages(): Promise<Message[]> {
    return await db.select().from(messages)
      .orderBy(desc(messages.createdAt));
  }

  async updateMessageStatus(id: string, status: string, recipientCount?: number, openRate?: number): Promise<void> {
    const updateData: any = { status };
    if (recipientCount !== undefined) updateData.recipientCount = recipientCount;
    if (openRate !== undefined) updateData.openRate = openRate;

    await db.update(messages)
      .set(updateData)
      .where(eq(messages.id, id));
  }

  async getLatestStatistics(): Promise<Statistics | undefined> {
    const [stats] = await db.select().from(statistics)
      .orderBy(desc(statistics.date))
      .limit(1);
    return stats;
  }

  async updateStatistics(insertStats: InsertStatistics): Promise<Statistics> {
    const [stats] = await db.insert(statistics).values({
      ...insertStats,
      date: new Date(),
    }).returning();
    return stats;
  }

  async getStatisticsByDateRange(startDate: Date, endDate: Date): Promise<Statistics[]> {
    return await db.select().from(statistics)
      .where(and(
        gte(statistics.date, startDate),
        lte(statistics.date, endDate)
      ))
      .orderBy(desc(statistics.date));
  }
}

export const storage = new DatabaseStorage();
