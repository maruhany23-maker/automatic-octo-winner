import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { telegramBot } from "./bot";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Dashboard stats
  app.get("/api/dashboard/stats", async (req, res) => {
    try {
      const users = await storage.getAllUsers();
      const transactions = await storage.getAllTransactions();
      const stats = await storage.getLatestStatistics();
      
      const numbersReceived = transactions.filter(t => t.type === 'debit').length;
      const codesSent = transactions.filter(t => t.status === 'completed').length;
      const totalRevenue = transactions
        .filter(t => t.status === 'completed')
        .reduce((sum, t) => sum + parseFloat(t.amount || '0'), 0);
      
      res.json({
        totalUsers: users.length,
        numbersReceived,
        codesSent,
        totalRevenue: totalRevenue.toFixed(2),
        successRate: numbersReceived > 0 ? ((codesSent / numbersReceived) * 100).toFixed(1) : "0",
        avgResponseTime: "2.3",
        dailyRevenue: "234.00"
      });
    } catch (error) {
      console.error("Error fetching dashboard stats:", error);
      res.status(500).json({ message: "Failed to fetch statistics" });
    }
  });

  // Users management
  app.get("/api/users", async (req, res) => {
    try {
      const { search } = req.query;
      let users;
      
      if (search && typeof search === 'string') {
        users = await storage.searchUsers(search);
      } else {
        users = await storage.getAllUsers();
      }
      
      res.json(users);
    } catch (error) {
      console.error("Error fetching users:", error);
      res.status(500).json({ message: "Failed to fetch users" });
    }
  });

  app.post("/api/users/:id/balance", async (req, res) => {
    try {
      const { id } = req.params;
      const { amount } = req.body;
      
      if (!amount || isNaN(parseFloat(amount))) {
        return res.status(400).json({ message: "Invalid amount" });
      }
      
      const user = await storage.updateUserBalance(id, amount.toString());
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Create transaction record
      await storage.createTransaction({
        userId: id,
        type: parseFloat(amount) > 0 ? 'credit' : 'debit',
        amount: Math.abs(parseFloat(amount)).toString(),
        description: parseFloat(amount) > 0 ? 'Balance added by admin' : 'Balance deducted by admin',
        status: 'completed'
      });
      
      res.json(user);
    } catch (error) {
      console.error("Error updating balance:", error);
      res.status(500).json({ message: "Failed to update balance" });
    }
  });

  // Transactions
  app.get("/api/transactions", async (req, res) => {
    try {
      const transactions = await storage.getAllTransactions();
      res.json(transactions);
    } catch (error) {
      console.error("Error fetching transactions:", error);
      res.status(500).json({ message: "Failed to fetch transactions" });
    }
  });

  // Messaging
  app.post("/api/messages/broadcast", async (req, res) => {
    try {
      const { content } = req.body;
      
      if (!content || typeof content !== 'string') {
        return res.status(400).json({ message: "Message content is required" });
      }
      
      const message = await storage.createMessage({
        type: 'broadcast',
        content,
        status: 'pending'
      });
      
      // Send broadcast via bot
      await telegramBot.sendBroadcastMessage(content);
      
      // Update message status
      const users = await storage.getAllUsers();
      await storage.updateMessageStatus(message.id, 'sent', users.length, 85);
      
      res.json({ message: "Broadcast sent successfully" });
    } catch (error) {
      console.error("Error sending broadcast:", error);
      res.status(500).json({ message: "Failed to send broadcast" });
    }
  });

  app.post("/api/messages/direct", async (req, res) => {
    try {
      const { userId, content } = req.body;
      
      if (!userId || !content) {
        return res.status(400).json({ message: "User ID and content are required" });
      }
      
      const message = await storage.createMessage({
        type: 'direct',
        content,
        targetUserId: userId,
        status: 'pending'
      });
      
      const success = await telegramBot.sendDirectMessage(userId, content);
      
      await storage.updateMessageStatus(message.id, success ? 'sent' : 'failed', 1);
      
      res.json({ message: success ? "Message sent successfully" : "Failed to send message" });
    } catch (error) {
      console.error("Error sending direct message:", error);
      res.status(500).json({ message: "Failed to send message" });
    }
  });

  app.get("/api/messages", async (req, res) => {
    try {
      const messages = await storage.getAllMessages();
      res.json(messages);
    } catch (error) {
      console.error("Error fetching messages:", error);
      res.status(500).json({ message: "Failed to fetch messages" });
    }
  });

  // Subscription channels
  app.get("/api/channels", async (req, res) => {
    try {
      const channels = await storage.getSubscriptionChannels();
      res.json(channels);
    } catch (error) {
      console.error("Error fetching channels:", error);
      res.status(500).json({ message: "Failed to fetch channels" });
    }
  });

  app.post("/api/channels", async (req, res) => {
    try {
      const { name, username } = req.body;
      
      if (!name || !username) {
        return res.status(400).json({ message: "Name and username are required" });
      }
      
      const channel = await storage.createChannel({
        name,
        username: username.startsWith('@') ? username : `@${username}`
      });
      
      res.json(channel);
    } catch (error) {
      console.error("Error creating channel:", error);
      res.status(500).json({ message: "Failed to create channel" });
    }
  });

  app.delete("/api/channels/:id", async (req, res) => {
    try {
      const { id } = req.params;
      await storage.deleteChannel(id);
      res.json({ message: "Channel deleted successfully" });
    } catch (error) {
      console.error("Error deleting channel:", error);
      res.status(500).json({ message: "Failed to delete channel" });
    }
  });

  // Bot settings
  app.get("/api/settings", async (req, res) => {
    try {
      const settings = await storage.getBotSettings();
      res.json(settings || {});
    } catch (error) {
      console.error("Error fetching settings:", error);
      res.status(500).json({ message: "Failed to fetch settings" });
    }
  });

  app.put("/api/settings", async (req, res) => {
    try {
      const settings = await storage.updateBotSettings(req.body);
      res.json(settings);
    } catch (error) {
      console.error("Error updating settings:", error);
      res.status(500).json({ message: "Failed to update settings" });
    }
  });

  // Statistics
  app.get("/api/statistics", async (req, res) => {
    try {
      const stats = await storage.getLatestStatistics();
      res.json(stats);
    } catch (error) {
      console.error("Error fetching statistics:", error);
      res.status(500).json({ message: "Failed to fetch statistics" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
