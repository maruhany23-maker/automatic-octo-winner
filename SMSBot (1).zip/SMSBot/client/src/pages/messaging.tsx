import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

interface Message {
  id: string;
  type: 'broadcast' | 'direct';
  content: string;
  targetUserId?: string;
  recipientCount?: number;
  openRate?: number;
  status: string;
  createdAt: string;
}

export default function Messaging() {
  const [broadcastMessage, setBroadcastMessage] = useState("");
  const [includeImage, setIncludeImage] = useState(false);
  const [directUserId, setDirectUserId] = useState("");
  const [directMessage, setDirectMessage] = useState("");
  
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: messages = [] } = useQuery<Message[]>({
    queryKey: ['/api/messages'],
  });

  const { data: stats } = useQuery({
    queryKey: ['/api/dashboard/stats'],
  });

  const broadcastMutation = useMutation({
    mutationFn: (content: string) => apiRequest('POST', '/api/messages/broadcast', { content }),
    onSuccess: () => {
      toast({
        title: "تم الإرسال",
        description: "تم إرسال الرسالة الجماعية بنجاح",
      });
      setBroadcastMessage("");
      queryClient.invalidateQueries({ queryKey: ['/api/messages'] });
    },
    onError: () => {
      toast({
        title: "خطأ",
        description: "فشل في إرسال الرسالة",
        variant: "destructive",
      });
    },
  });

  const directMutation = useMutation({
    mutationFn: ({ userId, content }: { userId: string; content: string }) => 
      apiRequest('POST', '/api/messages/direct', { userId, content }),
    onSuccess: () => {
      toast({
        title: "تم الإرسال",
        description: "تم إرسال الرسالة بنجاح",
      });
      setDirectUserId("");
      setDirectMessage("");
      queryClient.invalidateQueries({ queryKey: ['/api/messages'] });
    },
    onError: () => {
      toast({
        title: "خطأ",
        description: "فشل في إرسال الرسالة",
        variant: "destructive",
      });
    },
  });

  const handleBroadcast = (e: React.FormEvent) => {
    e.preventDefault();
    if (!broadcastMessage.trim()) return;
    broadcastMutation.mutate(broadcastMessage);
  };

  const handleDirectMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!directUserId.trim() || !directMessage.trim()) return;
    directMutation.mutate({ userId: directUserId, content: directMessage });
  };

  return (
    <div className="flex-1 p-6">
      {/* Header */}
      <header className="bg-white shadow-sm border-b px-6 py-4 -mx-6 -mt-6 mb-6">
        <h2 className="text-2xl font-semibold text-gray-800" data-testid="page-title">
          الرسائل
        </h2>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Broadcast Message */}
        <Card>
          <CardHeader>
            <CardTitle>رسالة جماعية</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleBroadcast}>
              <div className="mb-4">
                <Label className="block text-sm font-medium text-gray-700 mb-2">
                  نص الرسالة
                </Label>
                <Textarea 
                  className="resize-none h-32"
                  placeholder="اكتب رسالتك هنا..."
                  value={broadcastMessage}
                  onChange={(e) => setBroadcastMessage(e.target.value)}
                  data-testid="textarea-broadcast-message"
                />
              </div>
              <div className="mb-4">
                <div className="flex items-center space-x-2 space-x-reverse">
                  <Checkbox 
                    checked={includeImage}
                    onCheckedChange={(checked) => setIncludeImage(!!checked)}
                    data-testid="checkbox-include-image"
                  />
                  <Label className="text-sm">إرفاق صورة</Label>
                </div>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-500">
                  سيتم إرسالها إلى{' '}
                  <span className="font-medium" data-testid="text-total-users">
                    {stats?.totalUsers || 0}
                  </span>{' '}
                  مستخدم
                </span>
                <Button 
                  type="submit"
                  className="bg-telegram-blue text-white hover:bg-telegram-dark"
                  disabled={broadcastMutation.isPending || !broadcastMessage.trim()}
                  data-testid="button-send-broadcast"
                >
                  {broadcastMutation.isPending ? 'جاري الإرسال...' : 'إرسال'}
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>

        {/* Direct Message */}
        <Card>
          <CardHeader>
            <CardTitle>رسالة مباشرة</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleDirectMessage}>
              <div className="mb-4">
                <Label className="block text-sm font-medium text-gray-700 mb-2">
                  آيدي المستخدم
                </Label>
                <Input 
                  placeholder="@username أو User ID"
                  value={directUserId}
                  onChange={(e) => setDirectUserId(e.target.value)}
                  data-testid="input-target-user"
                />
              </div>
              <div className="mb-4">
                <Label className="block text-sm font-medium text-gray-700 mb-2">
                  نص الرسالة
                </Label>
                <Textarea 
                  className="resize-none h-32"
                  placeholder="اكتب رسالتك هنا..."
                  value={directMessage}
                  onChange={(e) => setDirectMessage(e.target.value)}
                  data-testid="textarea-direct-message"
                />
              </div>
              <Button 
                type="submit"
                className="w-full bg-success text-white hover:bg-green-600"
                disabled={directMutation.isPending || !directUserId.trim() || !directMessage.trim()}
                data-testid="button-send-direct"
              >
                {directMutation.isPending ? 'جاري الإرسال...' : 'إرسال الرسالة'}
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>

      {/* Message History */}
      <Card className="mt-6">
        <CardHeader>
          <CardTitle>سجل الرسائل</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {messages.length === 0 ? (
              <p className="text-gray-500 text-center py-8" data-testid="text-no-messages">
                لا توجد رسائل
              </p>
            ) : (
              messages.map((message) => (
                <div key={message.id} className="border rounded-lg p-4" data-testid={`message-${message.id}`}>
                  <div className="flex justify-between items-start mb-2">
                    <div>
                      <span className="text-sm font-medium">
                        {message.type === 'broadcast' ? 'رسالة جماعية' : 'رسالة مباشرة'}
                      </span>
                      <span className="text-xs text-gray-500 mr-2">
                        {new Date(message.createdAt).toLocaleString('ar-EG')}
                      </span>
                    </div>
                    <Badge 
                      variant={message.status === 'sent' ? 'default' : 'destructive'}
                      data-testid={`message-status-${message.id}`}
                    >
                      {message.status === 'sent' ? 'تم الإرسال' : 'فشل'}
                    </Badge>
                  </div>
                  <p className="text-sm text-gray-700 mb-2" data-testid={`message-content-${message.id}`}>
                    {message.content}
                  </p>
                  {message.type === 'broadcast' && (
                    <div className="flex justify-between items-center text-xs text-gray-500">
                      <span>
                        تم الإرسال إلى:{' '}
                        <span className="font-medium" data-testid={`message-recipients-${message.id}`}>
                          {message.recipientCount || 0}
                        </span>{' '}
                        مستخدم
                      </span>
                      <span>
                        معدل الفتح:{' '}
                        <span className="font-medium" data-testid={`message-open-rate-${message.id}`}>
                          {message.openRate || 0}%
                        </span>
                      </span>
                    </div>
                  )}
                </div>
              ))
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
